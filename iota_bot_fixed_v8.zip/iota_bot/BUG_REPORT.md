# 🐛 Iota Bot — Full Audit Bug Report

---

## 🔴 CRITICAL BUGS (caused commands to stop working entirely)

### Bug 1: Wrong GIFS variable name in config.py
- **File**: `config.py`
- **Why**: `village_war.py` and `games.py` imported `GIFS` from config, but
  config only defined `_GIFS` (with leading underscore). This caused an
  `ImportError` at startup — crashing the entire bot before any handler
  could load. Every command including `/panel` appeared to "do nothing"
  because the bot never actually started.
- **Fix**: Added `GIFS = _GIFS` as a public alias in `config.py`.

### Bug 2: Wrong OWNER_USERNAME set (broke /panel auth + AI identity)
- **File**: `config.py`, `handlers/owner_panel.py`, `handlers/ai_chat.py`,
  `handlers/advanced_admin.py`, `bot.py`
- **Why**: A previous cleanup pass incorrectly replaced the owner's real
  username (`@Boobies_00`) with a bot username placeholder
  (`@IotaBot_Official`). This caused two problems:
  1. The AI system prompt gave wrong owner info when users asked "who made
     you", producing wrong answers in DMs/groups.
  2. Any owner-identity check (e.g. logging, panel messages) showed the
     wrong name.
- **Fix**: Corrected to `OWNER_USERNAME = "@Boobies_00"`, added
  `OWNER_NAME = "ɴᴏᴛʜɪɴɢ"` and `BOT_USERNAME = "Its_iotabot"` as separate
  constants. All files updated to use the right one in the right context.

### Bug 3: /panel silently failing due to no exception visibility
- **File**: `handlers/owner_panel.py`
- **Why**: The `owner_only` check was a simple if-statement. Any exception
  inside a panel command would bubble up to PTB's error handler, but there
  was no specific logging, so in logs it was invisible. Additionally the
  OWNER_ID comparison wasn't explicitly cast to int(), creating a risk of
  string vs int type mismatch in edge cases.
- **Fix**: Replaced with `@owner_only` decorator that: logs every call
  (user ID, command name), logs every rejection, wraps the entire handler
  body in try/except that logs the full traceback AND DMs the owner the
  error — so no crash is ever silent again.

---

## 🟠 SERIOUS BUGS (features broken, data desync)

### Bug 4: 5 handler files used disconnected SQLite DB
- **Files**: `handlers/fun.py`, `handlers/items.py`, `handlers/welcome.py`,
  `handlers/protection.py` (all previously used `utils/db.py` sqlite)
- **Why**: The rest of the bot uses MongoDB (`utils/mongo_db.py`). These
  files were writing/reading from a separate SQLite file, meaning `/gift`
  would deduct coins from SQLite while `/bal` read from MongoDB — showing
  different balances. Fixed in previous session, confirmed in this audit.

### Bug 5: MongoDB password placeholder
- **File**: `config.py` (`_MONGO_PASS = "YOUR_MONGODB_PASSWORD"`)
- **Why**: Bot could not connect to any database. All DB-backed commands
  (`/bal`, `/daily`, `/rob`, `/ludo`, etc.) failed silently.
- **Fix**: Added clear warning comments + startup connection check with
  DM to owner on failure.

---

## 🟡 MODERATE BUGS (UX broken, bad error messages)

### Bug 6: All bare `except:` blocks swallowing exceptions
- **Files**: `handlers/advanced_admin.py`, `handlers/games.py`,
  `handlers/village_war.py`, `handlers/economy.py`
- **Why**: `except:` (bare, no exception type, no logging) hides every
  error as if nothing happened. A wrong MongoDB call, a KeyError, a
  network timeout — all silently ignored.
- **Fix**: Converted all bare `except:` to `except Exception as e:` with
  `logger.debug(...)` logging the actual error details.

### Bug 7: Duplicate handler conflict (bluff, hack)
- **Files**: `handlers/games.py`, `bot.py`
- **Why**: Old single-player `/bluff` and numpad-style `/hack` implementations
  were still registered in addition to the new multiplayer versions.
- **Fix**: Removed dead code from `games.py`; only new `bluff_game.py` and
  `hack_game.py` versions are imported and registered.

### Bug 8: No startup logging for handler registration
- **File**: `bot.py`
- **Why**: With 200+ handlers, a missing import or wrong function name during
  main() import blocks would fail silently (try/except inside main()).
- **Fix**: Added command-logger middleware (group=-1, runs before everything),
  plus a handler registration summary log at startup that explicitly confirms
  `/panel` is registered or logs an error if it's missing.

---

## 🟢 NEW FEATURES ADDED

### Feature 1: Sticker/GIF/Photo smart reply system
- **File**: `handlers/sticker_reply.py`
- **What**: Iota replies to stickers with mood-matched stickers/GIFs, replies
  to GIFs with matching GIFs, reacts to photos with a 1-line AI caption.
- **Mood detection**: reads the sticker's built-in `emoji` field.
- **Group safety**: only triggers when bot is @tagged, replied to, or in DMs.

### Feature 2: /dm — Owner can DM any user through the bot
- **File**: `handlers/owner_panel.py`
- **Usage**: `/dm <user_id> <message>` — sends a message from Iota to any
  user ID. `/announce <group_id|all> <message>` — sends to specific group
  or all known groups.

### Feature 3: Clickable owner name (mention_owner helper)
- **File**: `utils/helpers.py` — `mention_owner()` function
- **What**: Returns `<a href="tg://user?id=OWNER_ID">ɴᴏᴛʜɪɴɢ</a>` — clicking
  the name opens the owner's Telegram profile.
- **Used in**: `/panel` response, `/botstats`, wherever owner is referenced.

### Feature 4: AI knows its own identity and creator correctly
- **File**: `handlers/ai_chat.py`
- **What**: System prompt updated with correct bot username (`@Its_iotabot`),
  owner name (`ɴᴏᴛʜɪɴɢ`), and owner username (`@Boobies_00`). AI now
  answers "tera owner kaun hai" with the correct name and handle.

---

## ⚠️ REMAINING RECOMMENDATIONS

1. **Add real sticker file_ids** to `handlers/sticker_reply.py`'s `_STICKERS`
   dict — right now it falls back to GIFs because the sticker ID lists are
   empty. Send stickers to @idstickerbot to get their file_ids.

2. **Set real MongoDB password** — `config.py` `_MONGO_PASS` is still a
   placeholder. Every DB command will fail until this is set.

3. **Verify bot token** — `BOT_TOKEN` in config.py appears to be a real token.
   If the bot was restarted/token refreshed, update it.

4. **Add sticker pack** — For Iota's own sticker set, create one at
   @Stickers bot and add the file_ids to `_STICKERS` in `sticker_reply.py`.

5. **Group AI trigger tuning** — Currently Iota replies to direct name
   addresses (e.g., "iota kya scene hai"). If this causes false triggers in
   your group, increase the strictness in `ai_chat.py`'s
   `_DIRECT_ADDRESS_RE` regex.

---

## 🔴 SESSION 2 — CRITICAL FIX: /panel and all owner commands crashing

### Bug 9: Unescaped "<placeholder>" text in HTML-mode messages (root cause of the /panel crash)
- **Files**: `handlers/owner_panel.py` and 13 other handler files
  (`admin.py`, `advanced_admin.py`, `economy.py`, `extra_games.py`,
  `games.py`, `group_tools.py`, `hack_game.py`, `items.py`, `protection.py`,
  `utility.py`, `village_war.py`, `welcome.py`, `start.py`, `intro.py`)
- **Why**: Usage-hint strings like `/setmodel free|premium <model>` were
  sent with `parse_mode="HTML"`. Telegram's HTML parser only understands a
  small whitelist of tags (`<b>`, `<code>`, `<a>`, etc.) — anything else
  starting with `<word>` is treated as an unknown/unsupported start tag and
  the ENTIRE message is rejected with `BadRequest: Can't parse entities`.
  This is exactly the crash reported: `/panel` → `owner_panel_cmd crashed!
  BadRequest: Can't parse entities: unsupported start tag "model"`.
  ~99 raw placeholders were found across the codebase (`<uid>`, `<amt>`,
  `<msg>`, `<model>`, `<user_id>`, `<troop_type>`, etc.) — a systemic,
  codebase-wide bug, not limited to the owner panel.
- **Fix**:
  1. Every raw `<placeholder>` in a Telegram-facing string is now HTML
     -escaped to `&lt;placeholder&gt;`, so it displays as literal text
     instead of being parsed as a tag.
  2. Added `utils/safe_html.py` — a small helper module (`safe_html()`,
     `placeholder()`, `safe_reply_html()`, `safe_edit_html()`) used across
     the owner panel to escape any user-controlled or dynamic text before
     it's interpolated into an HTML-mode message.
  3. The `owner_only` decorator's crash-reporter itself now escapes the
     exception message before sending it back — previously, an exception
     whose *text* contained an unescaped `<...>` (like this very bug) could
     make the crash-reporting message crash a second time.
  4. `/scan` now escapes user-controlled Telegram data (full name, username,
     name/username history) before display — previously a user could set
     their display name to break or spoof the scan output.

### Bug 10: Dead/broken balance-update code in Village War
- **File**: `handlers/village_war.py`
- **Why**: `defense_cmd` and `train_cmd` contained leftover debug code —
  a no-op `update_user(uid=u.id, **{})` call (the `**{}` means it updates
  nothing) sitting next to a raw, inconsistent direct MongoDB call. It
  happened to still work by accident but was fragile, confusing, and one
  step from silently failing to deduct coins.
- **Fix**: Replaced with the standard `add_balance(uid, -cost)` helper
  already used everywhere else in the file.

### Bug 11: /start sent two separate messages instead of one
- **File**: `handlers/start.py`
- **Why**: `start_cmd` always sent a photo message AND then unconditionally
  sent a second, separate text-only welcome message right after — even
  when the photo sent successfully. This is the "2 output" behaviour
  reported.
- **Fix**: Now sends exactly ONE `/start` reply — a photo+caption+buttons
  message. If every image mirror fails to send, it falls back to a single
  text-only message instead. Never both.

### Bug 12: Profile photo (PFP) never actually fetched or shown
- **Files**: `utils/helpers.py`, `handlers/economy.py` (`/pfp`),
  `handlers/extra_games.py` (`/profile`)
- **Why**: Despite the name, `/pfp` never called any Telegram API to fetch
  a profile photo — it only printed stats text. `/profile` had the same
  gap. There was no PFP-fetching code anywhere in the project.
- **Fix**: Added `get_profile_photo_id()` and `send_profile_photo_or_text()`
  to `utils/helpers.py`, which call `bot.get_user_profile_photos()` for the
  target user and send their real Telegram profile picture with the stats
  as a caption — falling back to text-only automatically if the user has
  no profile photo set or it can't be fetched.

### Bug 13: Broken/rotting GIF links, tiny fixed sticker/GIF pool
- **Files**: `handlers/sticker_reply.py`, `handlers/fun.py`, `handlers/games.py`,
  `config.py`; new file `utils/gif_provider.py`
- **Why**: All GIF replies (`+kiss`, `+hug`, sticker/GIF auto-replies, card
  game win/tie animations) used a small hardcoded list of specific Giphy
  media URLs (1–4 per mood). These individual links rot over time and give
  very little variety — nowhere near "unlimited".
- **Fix**: Added `utils/gif_provider.py`, which searches Tenor's live GIF
  catalog by mood/keyword (effectively unlimited, always-fresh results,
  no signup required), with the old static Giphy list kept only as a
  last-resort emergency fallback if Tenor is unreachable, and a final
  plain-text fallback so a GIF failure can never break a reply. Every send
  path now retries once with a fresh result before falling back.

### Bug 14: /help menu buttons for Economy, Village, and AI Chat did nothing
- **File**: `handlers/start.py`
- **Why**: `/help`'s inline keyboard included buttons with
  `callback_data="menu_economy"`, `"menu_village"`, and `"menu_ai"`, but
  `menu_callback`'s `content` dict never defined those keys — tapping them
  silently did nothing.
- **Fix**: Added full content sections for all three menus.

### New feature: /village — full empire dashboard
- **File**: `handlers/village_war.py`, registered in `bot.py`
- **What**: A single command showing resources, treasury/vault, gems,
  citizens/workers/troops breakdown, army summary, walls, defense, and
  building levels all at once — instead of needing to run `/storage`,
  `/vault`, `/troops`, and `/walls` separately every time.

### ⚠️ Still required from you
- `_MONGO_PASS` in `config.py` is still the placeholder
  `"YOUR_MONGODB_PASSWORD"`. Every database-backed command (`/bal`,
  `/daily`, `/panel`, `/village`, etc.) will fail to read/write data until
  you replace it with your real MongoDB Atlas password.

---

## 🔴 SESSION 3 — Ludo Mini App, permission system, /detail history, Stars

### 🚨 Bug 15 (CRITICAL): Ludo was mathematically unwinnable once a piece reached the home stretch
- **Files**: `handlers/ludo.py` (`_calc_new_pos`), new `utils/ludo_engine.py`
- **Why**: `_calc_new_pos()` recalculated a piece's relative position using
  the OUTER TRACK's modulo formula (`(current - start) % 52`) even for
  pieces already past position 52 (i.e. already in their color's home
  stretch, positions 53-58). Home-stretch cells aren't on the shared
  52-cell ring, so this formula produced a nonsensical result — a piece
  one step from winning (e.g. position 57 + dice 1) would appear to warp
  back onto the outer track instead of reaching home. This affected
  **every single game** — nobody could legally finish once any piece
  entered the final stretch. Related: `_can_move()` also incorrectly
  treated a blocked "overshoot" move (piece can't move exactly onto/past
  home) as a *legal* move, letting the picker show impossible moves.
- **Fix**: Home-stretch movement (position > 52) is now a simple
  straight-line addition capped at `WINNING_POS` (58), calculated
  separately from the outer-track math. `_can_move()` now correctly
  excludes no-op/overshoot moves. Verified with an automated test suite
  simulating full games, captures, safe cells, and the exact win
  scenario that was broken (see engine tests run during this session).

### New: Ludo Mini App (Telegram WebApp) — `/ludo`
- **New files**: `utils/ludo_engine.py`, `webapp/ludo_server.py`,
  `webapp/ludo/index.html`, `webapp/ludo/static/{css,js}/*`
- **What**: A real, visual, multiplayer Ludo board that opens inside
  Telegram via the Mini App feature — animated SVG board, live dice with
  a tumble animation, spectator mode, and in-lobby/in-game chat, all
  synced in real time via WebSocket. Built on the exact same rules
  engine as the chat game (now shared via `utils/ludo_engine.py`, with
  the home-stretch bug fixed at the source) so both experiences always
  agree on what's legal.
- **Security**: every Mini App request is authenticated via Telegram's
  official `initData` HMAC-SHA256 signature scheme — a user can never
  impersonate another player, move on someone else's turn, or forge
  their identity to manipulate balances.
- **Setup required**: Telegram Mini Apps must be served over HTTPS from
  a public domain. Set `WEBAPP_BASE_URL` in `config.py` once your bot is
  hosted somewhere with a real HTTPS domain — see README.md's "Ludo Mini
  App Setup" section. Until then, `/ludo` automatically falls back to
  the classic chat-button game (zero setup, always works).

### Bug 16: `/detail` history only ever showed ONE name/username, never accumulated
- **File**: `utils/mongo_db.py` (`ensure_user`)
- **Why**: When a user's name/username changed, the code appended the
  NEW value to history — but never recorded the OLD value being replaced.
  So history could only ever contain the single most recent value, never
  actually accumulating a real change-log (this is why `/detail` showed
  far less than other bots that track full history).
- **Fix**: `ensure_user()` now correctly pushes the OUTGOING name/username
  onto history when it changes (not the incoming one), and seeds the very
  first name/username into history at account creation. `/detail` also
  now always shows the live current value at the top of the list in
  addition to full past history (up to 10 entries each).

### New: Unified permission system — `utils/permissions.py`
- **Why**: Admin/owner checks were done ad-hoc across 15+ places with
  manually repeated, inconsistent code (different error messages, easy
  to forget on new commands, no reusable DM-only/group-only concept).
- **What**: `@owner_only`, `@admin_only`, `@group_only`, `@dm_only`,
  `@requires_not_banned` — clean, stackable decorators with one
  consistent error message each, for all new commands to build on.
- **Also fixed**: `is_admin()` in `utils/helpers.py` now always treats
  the bot owner as privileged, everywhere — previously the owner could
  be blocked from admin-only commands in a group where they weren't
  formally promoted to admin.

### Bug 17: User-controlled data injected raw into HTML in `/starsstats`
- **File**: `handlers/owner_panel.py`
- **Why**: `r.get('full_name', '?')` (a payer's Telegram display name) was
  interpolated directly into an HTML-mode message — the same class of bug
  as Session 2's `/panel` crash, just with user data instead of a literal
  placeholder string.
- **Fix**: Escaped with `safe_html()`.

### Stars payments — confirmed working as intended, documented clearly
No code change was needed here: Telegram Stars sent via `send_invoice()`
always accumulate on the bot's own balance, which belongs to whichever
Telegram account registered the bot with @BotFather. As long as
`config.OWNER_ID`'s account is that owner, every Star already lands with
them automatically — added a clear top-of-file explanation in
`handlers/premium.py` and README.md so this is documented for the future,
and confirmed no user-facing message anywhere mentions the owner or fund
destination (verified `/starsstats` stays owner-only).

---

## 🔴 SESSION 4 — /detail root cause, HTML-injection audit, new Werewolf game

### 🚨 Bug 18 (ROOT CAUSE): `/detail` history still incomplete after Session 3's fix
- **File**: `bot.py`
- **Why**: Session 3 fixed `ensure_user()` to correctly push the outgoing
  name/username into history on a change — but that function was still
  only ever called by SPECIFIC commands (`/start`, `/bal`, etc.), never
  on every message. If a user changed their Telegram name multiple times
  between running any Iota command, every intermediate name was silently
  never seen by the bot at all — there was nothing to record, no matter
  how correct the recording logic itself was. This is why `/detail` kept
  showing far less history than a bot that tracks identity on every
  message.
- **Fix**: Added a global identity-tracking middleware
  (`TypeHandler(Update, ...)` at `group=-2`, i.e. runs before everything
  else) that calls `ensure_user()` on every update the bot receives —
  any message, any button press — not just specific commands. Debounced
  per-user to once every 5 minutes to keep MongoDB load negligible even
  in busy groups. This is the actual, complete fix; Session 3's change
  was necessary but not sufficient on its own.

### Bug 19: Widespread unescaped user-controlled text in HTML messages (same bug class as the /panel crash, different data)
Found and fixed **8 more** instances of raw user/admin-controlled text
interpolated directly into `parse_mode="HTML"` messages — each one a
potential crash (if it contains `<word>`-shaped text) or, in the Ludo/
Bluff cases, a real HTML-injection risk since Telegram display names are
fully user-controlled:
- `handlers/advanced_admin.py`: group title (3 places), saved note name
  (save confirmation + notes list + note-recall), custom rules text.
- `handlers/economy.py`: group title (group leaderboard header).
- `handlers/protection.py`: group title (3 places — reports, settings).
- `handlers/welcome.py`: group title (goodbye message).
- `handlers/ludo.py`: player display name (`u.first_name`) — escaped
  once at the point it enters game state so every downstream `<b>{name}</b>`
  usage throughout the file is automatically safe.
- `handlers/bluff_game.py`: same fix, same reasoning, for its player list.
- `handlers/owner_panel.py`: payer's display name in `/starsstats`.

### New: Interactive Welcome Settings panel — `/setwelcome`
- **File**: `handlers/welcome.py`
- **What**: `/setwelcome` (no args) now shows a live inline-button panel
  (Enable/Disable, GIF on/off, Set Custom Message, Reset, Preview) instead
  of only a plain-text usage message — matching the interactive settings
  UX shown in the reference screenshots. The original text shortcuts
  (`/setwelcome on`, `/setwelcome gif off`, etc.) still work unchanged for
  power users. Welcome GIFs now also pull from the same live/unlimited
  Tenor search as the rest of the bot instead of a small fixed list.

### New mini-game: 🐺 Werewolf (social deduction) — `handlers/werewolf_game.py`
- **Commands**: `/werewolf` (host), `/join`, `/prowl` (werewolf DM action),
  `/peek` (seer DM action), `/heal` (doctor DM action), `/vote` (day
  phase), `/wwend` (cancel).
- **What**: A full night/day social-deduction game — Werewolves, a Seer,
  a Doctor, and Villagers, with secret roles sent via DM, a night phase
  for hidden actions, and a day phase for group discussion + voting.
  Winners split a coin reward. Chosen because it's a genuinely different
  mechanic from everything else already in the bot (card/bluff/hack are
  all different game types) and is a strong fit for group engagement.
- **Correctness**: role distribution and win-condition logic were both
  covered by an automated test sweep across every supported player count
  (5-10) before shipping.
- **Edge case handled**: a player theoretically in more than one active
  Werewolf game at once (different groups) gets a clear "which game?"
  message instead of a DM action silently applying to the wrong game.

---

## 🔴 SESSION 5 — Broadcast media/reliability, reactions, daily timing, rob/protection bugs

### Bug 20: Broadcast had a ~91% failure rate and no media support
- **File**: `handlers/owner_panel.py`, `utils/mongo_db.py`
- **Why**: Telegram permanently blocks a bot from DMing users who've
  blocked it or deleted their account — the old code retried EVERY known
  user on EVERY broadcast, including permanently-dead ones, forever.
  There was also no way to send anything but plain text.
- **Fix**: `/broadcast` and `/announce` now support photo/video/GIF/
  sticker/voice/audio/document via reply. Failures are categorized
  (blocked/deactivated vs. rate-limited vs. other); permanently blocked
  users are automatically marked `dm_unreachable` in MongoDB and skipped
  on all future broadcasts (and un-marked automatically the next time
  they DM the bot), so the failure count shrinks over time instead of
  staying stuck. Telegram's flood-control (`RetryAfter`) is now handled
  by waiting exactly as long as asked and retrying, instead of counting
  it as a failure.

### New: Emoji reactions — `utils/reactions.py`
Iota can now react to messages with a native Telegram emoji reaction
(the tap-to-react bubble) in both DMs and groups, when the content
clearly calls for it (wins, jokes, sadness, compliments, etc.) — not
every message, to avoid feeling spammy. Runs as a fire-and-forget
background task so it can never delay Iota's actual reply.

### Bug 21: Daily reward timing was completely unreliable
- **File**: `handlers/economy.py`
- **Why**: `auto_daily_job`'s MongoDB query had the same key
  (`"last_daily"`) TWICE in one Python dict — the second value silently
  overwrote the first, so the "has 24h actually passed?" condition was
  discarded entirely before the query ever ran. It also had no
  `is_premium` filter, so it was auto-crediting FREE users too.
- **Fix**: Free users now claim manually via `/daily` only. Premium
  users get it manually via `/daily` too, OR automatically (fixed query,
  `is_premium: True` only, checked every 10 minutes instead of hourly
  for tighter timing). Cooldown is exactly 86400 seconds (24h) for both.

### Bug 22: `/rob <amount>` completely ignored the amount typed
- **File**: `handlers/economy.py`
- **Why**: The rob amount was always `random.randint(100, max_rob)` —
  whatever number the user typed had zero effect on the outcome. This
  is why `/rob 50` could rob $147, or `/rob 100` could report "victim
  has $0" regardless of their actual balance.
- **Fix**: The requested amount is now honored, capped by the tier's
  max-per-rob limit and the victim's actual balance. No amount given
  still falls back to the original random-roll behaviour.

### Bug 23: Protection status leaking exact countdown to other users
- **Files**: `handlers/economy.py` (`/bal`, `/rob`, `/kill`),
  `handlers/village_war.py` (`/attack`)
- **Why**: These all showed a target's exact remaining protection time
  ("protected for 23h 57m") to ANYONE, publicly, in groups — completely
  bypassing the careful DM-only/premium-gated privacy design `/check`
  already had. This let anyone time an attack for the exact second
  protection expired.
- **Fix**: Own status in DM still shows exact time. Own status in a
  group shows generic + "DM me /check for exact time". Someone ELSE's
  status, anywhere, NEVER shows the exact countdown — only a boolean
  "protected" flag, with a nudge toward /check (which stays premium-only
  and DM-delivered, exactly as designed).

### Bug 24: `/protect 1d` was free — now costs 400 coins as requested
- **File**: `config.py`, `handlers/economy.py`, `handlers/premium.py`
- `PROTECT_1D_COST` changed from `0` to `400`. `/protect 1d` now deducts
  coins like `2d` already did (which remains premium-only at 1000).

### Bug 25: Voice/TTS was completely broken (deprecated model + invalid speaker)
- **File**: `utils/sarvam.py`, `handlers/utility.py`
- **Why**: Used `model="bulbul:v1"`, which Sarvam has fully deprecated
  and no longer supports at all — guaranteed failure on every single
  call. Also used `speaker="meera"`, which was never a valid speaker
  name for any Sarvam TTS model, for Hindi specifically (the most-used
  language here).
- **Fix**: Upgraded to `bulbul:v2` with `anushka` (a real, valid,
  well-supported voice) as the default across all languages. Errors are
  now logged with the actual failure reason instead of silently
  swallowed, so future issues are debuggable instead of invisible.

### Bug 26: AI replies leaking raw search-result blocks; confused replies to insults; hallucinated fake links
- **File**: `handlers/ai_chat.py`
- **Why**: (1) The system prompt didn't forbid echoing the injected
  `[SEARCH RESULTS]` block, and at temperature 0.9 the model sometimes
  dumped it straight into the reply the user saw. (2) A narrow "if
  someone calls you Baka" rule was being over-generalized by the model
  to ANY insult, producing confused "old name" replies to things like
  "battamiz" that were never about an old bot name. (3) The model was
  inventing fake YouTube/website links with no instruction against it.
- **Fix**: Added an explicit instruction never to echo the search block,
  PLUS a regex safety-net that strips any leaked block even if the model
  ignores the instruction. Narrowed the special-case rule to the exact
  word "Baka" only. Added a hard "never fabricate links" rule. Also
  tightened the search-trigger heuristic to skip insults/banter and
  date/time questions (the current date is already injected directly —
  searching for it was both wasteful and a source of the leak).

### Bug 27: /start's menu buttons (Groups/Promoter/Friends/Games) silently failed
- **File**: `handlers/start.py`
- **Why**: `/start` sends a PHOTO message (village image + caption) as
  of an earlier fix, but `menu_callback` still called
  `edit_message_text()` unconditionally — which fails with "There is no
  text in the message to edit" on any message that carries media. This
  made every menu button under /start silently do nothing.
- **Fix**: Now checks for `q.message.photo` and uses
  `edit_message_caption()` when needed, `edit_message_text()` otherwise.
  Found and fixed the identical bug in 6 more places inside
  `handlers/ludo.py` (the Ludo lobby is sent via `reply_animation`, so
  every button on it had the same class of failure) via a new shared
  `_safe_edit()` helper.

---

## 🔴 SESSION 6 — /connect (shared AI memory), bot self-knowledge, personality tuning

### New feature: /connect — shared AI memory between two users
- **New files**: `utils/connect.py`, `handlers/connect.py`
- **What**: `/connect` (reply to a user, or `/connect @username`) sends
  a DM request; the other person taps Accept/Deny. Once accepted, Iota
  merges both users' AI-chat memory into one shared context for 24
  hours, so she gives consistent answers to either of them instead of
  remembering them completely separately. `/disconnect` ends it early;
  `/connect_id` shows the active connection's status. A background job
  automatically closes expired connections and DMs both users.
- Requires the invited user to have DM'd the bot before (a Telegram
  platform rule) — handled with a clear message instead of a silent
  failure, consistent with how the rest of the bot handles this.

### New: Iota's self-knowledge of her own commands (`utils/command_knowledge.py`)
Users can now ask Iota herself what she can do or how to use a command,
and she'll answer accurately — using ONE shared, hand-curated list of
user-facing commands that both `/help` and the AI's system prompt read
from. Deliberately contains ZERO owner-panel commands (broadcast,
/panel, /scan, /setmodel, etc.) — not filtered out by instruction, but
never included in the source data at all, so there's nothing for the AI
to leak even by mistake. If asked about anything administrative that
isn't in the list, Iota is instructed to say she doesn't know about it
rather than guess.

### Personality tuning
- Removed the "Baka" identity-confusion special case (superseded by
  Session 5's narrower fix, now removed entirely per request).
- Added explicit tone-matching guidance for how Iota talks to girls:
  soft/innocent if they're being sweet, disengaged/cool if they're being
  rude, normal-friend-banter otherwise — matches tone rather than being
  uniformly flashy or uniformly guarded.
- Iota now actually receives the user's first name and username (she
  didn't have access to either before), with an explicit rule to use
  the name naturally but only mention the @username if directly asked.

### New owner commands: /premiumlist and /userslist
Paginated (20/page), owner-only lists of all premium users and all
users respectively, with names, usernames, balances, and status tags —
for when the owner needs to browse the user base rather than look up
one user at a time via /scan.

### Verified NOT still-present bugs (were already fixed in Session 4, confirmed via re-audit)
Re-verified the `/rob $0` "same name shown twice" bug and the
`/kill`-bypasses-protection concern reported again this session — both
are already correctly fixed in the current codebase (confirmed via
direct code review). The screenshots showing them were from a bot
deployment that hadn't yet been updated with the Session 4 fix — a
deployment/versioning gap, not a remaining code bug.

---

## 🔴 SESSION 7 — Sticker packs, TTS panel, slots, personality rewrite, name-mention activation

### Bug 28: Leftover "Baka" branding in the coin tournament leaderboard
- **File**: `handlers/games.py` — `"🏆 Bᴀᴋᴀ Cᴏɪɴ Tᴏᴜʀɴᴀᴍᴇɴᴛ..."` renamed to Iota.
  Full codebase scan confirmed no other user-facing Baka references remain.

### New: Owner-managed sticker packs (real sticker-to-sticker replies)
- **New DB functions**: `utils/mongo_db.py` (`add_sticker_to_pack`,
  `get_stickers_for_mood`, `list_all_sticker_packs`, `clear_sticker_pack`)
- **New owner commands**: `/addsticker <mood>` (reply to a sticker),
  `/stickerpacks`, `/previewsticker <mood>`, `/clearstickers <mood>`
- **Why**: previously, giving Iota real reply-stickers required hand-
  editing a Python dict and redeploying — not something the owner could
  do from Telegram. Now it's fully manageable via bot commands, stored
  in MongoDB, and `handlers/sticker_reply.py` reads live from the
  database — Iota will use an owner-added sticker for a mood whenever
  one exists, falling back to the live GIF search otherwise.

### New: Owner-configurable TTS/Voice settings panel
- **File**: `utils/sarvam.py`, new owner commands `/ttssettings` and
  `/previewtts` in `handlers/owner_panel.py`
- The owner can now change Iota's voice model, speaker, speed (pace),
  pitch, and loudness directly from Telegram, persisted to MongoDB
  (survives restarts) — instead of these being hardcoded constants only
  editable in source code.

### New game: 🎰 /slots — casino slot machine
- **New file**: `handlers/slots_game.py`
- Uses Telegram's own NATIVE animated slot-machine dice
  (`bot.send_dice(emoji=SLOT_MACHINE)`) instead of a custom fake-spin
  UI — the outcome is generated server-side by Telegram itself, so
  results are provably fair and Iota literally cannot influence them.
- **Caught and fixed a real balance bug before shipping**: a first-draft
  payout table (5x three-of-a-kind, 1.5x any-two-matching, 10x jackpot)
  was verified by simulating all 64 possible Telegram dice outcomes to
  have a **-23% house edge** — the average player would profit
  infinitely and could farm unlimited coins, breaking the whole
  economy. Rebalanced to 15x jackpot / 4x three-of-a-kind / 1x (bet
  returned) for two-matching / lose on no-match, which simulates to a
  healthy +1.6% house edge — verified mathematically before shipping,
  not just eyeballed.

### Personality rewrite: Iota's own original voice
- **File**: `handlers/ai_chat.py`
- Removed the "how Iota treats girls" tone-matching section per request.
- Rewrote the entire personality section from scratch — same *quality*
  of natural, witty, short-reply conversation as the reference "Baka"
  transcripts, but in Iota's own phrasing throughout (not copied lines
  or copied specific threats/comebacks) — confident, a little dry with
  rude messages, mildly protective of her owner specifically, doesn't
  over-explain or get defensive about being an AI.

### New: Group activation on saying Iota's name anywhere in a message
- **File**: `handlers/ai_chat.py` — `_DIRECT_ADDRESS_RE`
- **Why**: the old regex only matched "iota" at the very START of a
  message (e.g. "iota kya scene hai"), so something like "yaar iota
  bahut acchi hai" never triggered a response — only @mentions or
  direct replies did.
- **Fix**: now matches "iota" as a whole word ANYWHERE in the message
  (word-boundary matched, so "iotaphone" or "chiiota" do NOT falsely
  trigger) — verified against both trigger and false-positive cases
  before shipping.

### New: /q — resend Iota's last reply
Instant, no new AI call — just re-sends whatever Iota last said to you
from memory. Useful if her last message scrolled away. Correctly reuses
the already-HTML-converted, already-leak-stripped stored text rather
than reprocessing it.

### Bug 29: Systemic raw-exception/free-text HTML injection across `.` prefix admin commands
- **File**: `handlers/admin.py`
- **Why**: the same class of bug fixed in owner_panel.py/ludo.py in
  earlier sessions was still present here — 14 instances of
  `f"❌ {e}"` (raw `TelegramError` text, which can contain `<`/`>`,
  injected straight into an HTML-mode message), plus `.warn`/`.ban`'s
  free-text `reason` argument and `.title`'s custom title both
  interpolated unescaped into `<b>` tags.
- **Fix**: all 14 exception-message sites now use `safe_html()`; reason
  and custom-title text are now escaped too. (Checked `.add`/`.remove`'s
  power-level argument specifically — that one was already safe, since
  it's validated against a fixed allowlist before ever reaching the
  confirmation message, so no fix was needed there.)

### New: /start's update channel button
- **File**: `config.py` (`UPDATE_CHANNEL_USERNAME`), `handlers/start.py`
- The "Friends" button in `/start`'s menu is now a direct link to your
  update channel once you create one and set its username in
  `config.py` — suggested a short name ("IotaUpdates") for you to check
  availability on and create yourself. Falls back to the original
  Friends menu automatically if left unconfigured, so nothing ever
  points to a broken link.

### Confirmed already-complete: `.` prefix admin command set
Cross-checked the full requested list (`.warns`, `.warn`, `.unwarn`,
`.mute`, `.dmute`, `.unmute`, `.ban`, `.unban`, `.kick`, `.promote`
with power levels 0-3, `.demote`, `.add`/`.remove` power, `.demote_all`,
`.title`, `.pin`, `.unpin`, `.d`, `.help`) against `handlers/admin.py`'s
dispatch table — every single one was already implemented correctly
(only the injection-safety issue above needed fixing, not the features
themselves).

---

## 🔴 SESSION 8 — Card game overhaul, system-wide /close, theft alerts, broadcast history, real /q

### Corrected misunderstanding: /q is a QUOTE STICKER generator, not a "resend last reply"
Session 7 built `/q` as a memory-lookup shortcut based on an ambiguous
screenshot. The follow-up screenshots clarified the real reference
feature: replying to a message with `/q` renders it as a styled
**image sticker** (name + avatar + message text on a card), like the
popular "Quotly"-style bots. The old (wrong) `/q` was removed entirely
and replaced with the real thing:
- **New files**: `utils/font_manager.py` (layered font strategy: bundled
  → auto-download once → system fallback, so it works both offline-safe
  after first setup and out-of-the-box on a fresh clone with internet),
  `utils/quote_render.py` (the actual card renderer — Pillow-based,
  outputs a proper 512×512 transparent WEBP, Telegram's required static
  sticker format), `handlers/quote_sticker.py` (the command).
- Supports: any length of text (auto-wraps, shrinks font, truncates with
  an ellipsis as a last resort rather than overflowing), Hindi/
  Devanagari + English + mixed-script + emoji, real profile photos with
  a colored initial-letter fallback when none is set.
- Specific, clear error messages for unsupported message types (sticker,
  photo/video with no caption, voice/audio) instead of a generic failure.
- Verified end-to-end with rendered test images before shipping (see
  the in-session screenshots) — checked wrapping, font-shrinking, and
  long-name truncation all worked correctly.

### Bug 30: Card game — no bet limits, no lobby timeout, tie-branch fee bug, streak display bug, cancel-permission bug
- **File**: `handlers/games.py`
- **No bet limits**: `/bet` had no minimum or maximum at all — Python's
  arbitrary-precision integers meant even a 30-digit "bet" was accepted
  as syntactically valid before the balance check caught it. Added
  `CARD_MIN_BET`/`CARD_MAX_BET` (config.py), consistent with every other
  betting game in the bot.
- **No lobby timeout**: an abandoned "waiting for player 2" game sat in
  memory forever. Added a 90-second auto-cancel with a clear group
  notification (see `_card_lobby_timeout`).
- **🚨 Security bug**: `card_cancel_`'s callback handler removed the game
  from memory (`_card_games.pop(...)`) BEFORE checking whether the
  caller was actually the host — so any random player could destroy
  someone else's game lobby by tapping Cancel, even though the bot then
  (too late) told them "Only host can cancel!". Fixed by checking
  permission before mutating any state.
- **Tie-branch fee bug**: the tie-result message always claimed a fee
  was taken ("Won: X (10% Fee)") but the actual prize math never
  deducted one in that branch — only the non-tie branch did. Fee is now
  genuinely applied (and premium players stay fee-exempt) in both.
- **Streak display bug**: the result message computed
  `new_streak / (old_best_streak + 1)` using a stale pre-update value
  with a meaningless "+1" fudge factor, instead of the actual final
  best-streak after the DB write. Now tracks and displays real values.
- Removed a redundant `get_chat()` API call on every join (host's name
  is now stored once at game creation).

### Bug 31 (major, root-cause): /close only ever gated 2 of ~35 relevant commands
- **New files**: `utils/system_gate.py` (`games_gate`, `economy_gate`,
  `village_gate` decorators), rewritten `utils/mongo_db.py` status
  storage (`get_system_status`/`set_system_status`, replacing the old
  single `is_gaming_open` boolean with three independent systems).
- **Why**: `/close` set exactly ONE flag, and that flag was checked in
  exactly 2 commands (`/card`, `/bet`). Every other game (bomb, ludo,
  bluff, hack, wordgame, hangman, quiz, tictactoe, rps, werewolf, slots)
  and EVERY economy command (`/daily`, `/bal`, `/rob`, `/kill`,
  `/revive`, `/protect`, `/give`, `/toprich`, `/wallet`, `/gprotect`)
  and ALL 16 village-war commands completely ignored `/close` — exactly
  the bug reported, matching the reference bot's screenshots.
- **Fix**: `/close` and `/open` now control three independent systems
  (games / economy / village) together by default, or individually via
  `/close economy` etc. Every one of the ~35 affected commands across
  6 files now carries the appropriate `@games_gate`/`@economy_gate`/
  `@village_gate` decorator — a single consistent, unmissable mechanism
  instead of relying on each command remembering its own check.

### New: High-value theft DM alert (5000+ coins)
- **File**: `handlers/economy.py`, `config.py`
  (`HIGH_VALUE_THEFT_THRESHOLD`)
- If a `/rob` steals 5000+ coins, the victim now gets DM'd directly
  (in addition to the group message) so they find out even if they're
  not watching the chat — wrapped in try/except so a failed DM (never
  started the bot, blocked it) can never break the rob command itself.

### New: Broadcast/Announce deletion + history
- **New DB functions**: `utils/mongo_db.py`
  (`create_broadcast_record`, `add_broadcast_target`,
  `get_broadcast_record`, `list_broadcast_history`)
- **New owner commands**: `/delbroadcast <id> [chat_id]` (delete a past
  broadcast/announce from everywhere it reached, or just one chat),
  `/broadcasthistory` (last 20 broadcasts/announces with IDs, previews,
  and reach counts).
- Every `/broadcast` and `/announce` now records exactly which chats got
  which message ID, so any past send can be recalled later.

### Personality: kept the natural/witty rewrite from Session 7, declined one specific pattern
Reviewed further reference conversation examples showing a clingy,
romantic "girlfriend" roleplay dynamic (accepting pet names like "baby"/
a new nickname, escalating "i really care for u" language, apologizing
submissively to guilt-tripping/relationship accusations). Deliberately
did NOT build this into Iota's personality — that kind of romantic
roleplay dynamic is inappropriate for a bot broadly accessible on
Telegram without age verification. Iota's personality stays warm, witty,
and natural (per Session 7's rewrite) without the romantic-partner framing.

### ⚠️ Scope note — what wasn't fully completed this session
Given the enormous breadth of this session's request (a full line-by-
line audit of the entire codebase, every game, every admin command,
full database/transaction/rollback review, full logging system,
automated test suite, etc.), the highest-impact, concretely-identified
items were prioritized and fixed as documented above. A genuinely
complete "audit every single line of the entire codebase" pass across
a project this size is a multi-week undertaking for a human team, not
something that can be exhaustively completed in one sitting — but every
specific, concrete bug pointed to (or identifiable via careful review of
the referenced screenshots) has been fixed. If specific remaining areas
matter most to you, flagging them individually next session will get
them the same close attention the items above received.
