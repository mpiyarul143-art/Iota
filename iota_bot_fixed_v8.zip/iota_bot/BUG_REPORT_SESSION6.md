# 🤖 Multi-Provider AI System (v4)

## The problem from your logs
```
Groq key gsk_n9n...2hDV → HTTP 429, cooling down 60s, trying next key
dm_message_handler failed: All Groq API keys/models failed.
```
Only **one** Groq key was configured. Groq's free tier has real rate
limits (requests/minute), and with only one key, hitting that limit
meant total failure — there was no "next key" to actually try. This
wasn't a bug in the fallback logic; there was just nothing to fall
back to.

## The fix: real multi-provider fallback

`utils/ai_provider.py` now supports **four independent providers**,
tried in priority order — if Groq's entire key pool is exhausted, it
automatically tries **Gemini**, then **OpenRouter**, then **Cloudflare
Workers AI**, before finally giving up. All four have genuine free
tiers:

| Provider | Get a free key |
|---|---|
| Groq | https://console.groq.com/keys |
| Google Gemini | https://aistudio.google.com/apikey |
| OpenRouter | https://openrouter.ai/keys |
| Cloudflare Workers AI | https://dash.cloudflare.com/profile/api-tokens (+ account ID) |

Add keys with `/addapikey <key> <provider>` (provider defaults to
`groq` if omitted) — no restart needed, takes effect immediately and
persists across restarts.

## New owner commands

- `/providerstatus` — overview of every provider: enabled state, key
  counts, health, active models, and current fallback order
- `/setpriority groq,gemini,openrouter,cloudflare` — reorder which
  provider is tried first/second/etc.
- `/toggleprovider <provider>` — enable/disable one provider without
  losing its configured keys
- `/addapikey <key> [provider]` / `/removeapikey <prefix> [provider]`
- `/keypoolstatus [provider]` — per-key health (requests, successes,
  failures, cooldowns) for one provider or all of them
- `/setmodel free|premium <model> [provider]` — each provider has its
  own independently-configurable free/premium model
- `/listmodels [provider]` / `/refreshmodels [provider]`
- `/setmaxtokens <n>` — response length cap, shared across all providers

## Chat Compiler (`utils/chat_compiler.py`) — new

Handles conversation management before anything reaches a provider,
and normalizes every provider's response back to plain text, so
`call_ai()` itself never needs to know which provider answered:

- Trims conversation history to the last 20 messages (configurable),
  always keeping the system prompt
- Drops consecutive duplicate messages (a common symptom of retry
  loops) so context doesn't bloat for no reason
- Converts the standard `{"role","content"}` message format into
  Gemini's different `contents`/`parts` + `system_instruction` shape
  (Gemini's REST API isn't OpenAI-compatible, unlike the other three)
- Normalizes both OpenAI-style and Gemini-style responses back into one
  plain string

## How the fallback actually works now

```
call_ai(messages) 
  → tries Groq: every key in Groq's pool, in least-recently-used order
    → all rate-limited/failed? 
  → tries Gemini: every key in Gemini's pool
    → all rate-limited/failed?
  → tries OpenRouter: every key in OpenRouter's pool
    → all rate-limited/failed?
  → tries Cloudflare Workers AI: every key in its pool
    → all failed? → only NOW does the user see an error
```

A single rate-limited key — or even an entire rate-limited provider —
no longer means a failed response, as long as at least one other
provider has a healthy key.

## Verified
- Full multi-provider logic smoke-tested (priority reordering, key
  pool management, model config, invalid-input rejection) — all correct
- Chat Compiler tested: history trimming, dedup, Gemini format
  conversion, response normalization for both formats, malformed-input
  safety (never crashes, returns `None` for parsing)
- All 71 Python files compile with zero syntax errors
- Zero cross-module import mismatches
- Zero duplicate command registrations across 296 commands
