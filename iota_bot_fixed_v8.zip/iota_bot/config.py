from urllib.parse import quote_plus

BOT_TOKEN      = "8740709364:AAF0i0ZsJlgbIK1mXK85NUVJwfn7AMljLmU"

# ── Owner identity (the human who owns/runs this bot) ──────────────────
OWNER_ID       = 6998484205
OWNER_USERNAME = "@Boobies_00"   # real owner Telegram username
OWNER_NAME     = "ɴᴏᴛʜɪɴɢ"        # owner's display name (used for clickable mentions)

# ── Bot's own identity (Iota herself) ───────────────────────────────────
BOT_NAME       = "Iota"
BOT_USERNAME   = "Its_iotabot"    # no leading @ — used to build t.me links

# ── Update channel ──────────────────────────────────────────────────────
# Shown as a button in /start's menu. Suggested short, on-brand name:
# "IotaUpdates" — check availability and create the channel on Telegram
# yourself (make it PUBLIC so it has a @username), then paste that exact
# username below (no leading @). Leave blank to hide the button entirely
# until you've set this up — /start won't show a broken/missing link.
UPDATE_CHANNEL_USERNAME = ""   # e.g. "IotaUpdates" (no leading @)

# ── Ludo Mini App ────────────────────────────────────────────────────────
# Telegram Mini Apps MUST be served over HTTPS from a real, public domain
# (not localhost / bare IP — Telegram will refuse to open the WebApp
# otherwise). Point this at wherever this bot's process is reachable from
# the internet (e.g. your host's HTTPS domain, or a reverse-proxy/tunnel
# in front of WEBAPP_PORT below). Leave blank to keep /ludo as chat-only
# until this is configured — /ludo will explain this to the host instead
# of sending a broken WebApp button.
WEBAPP_BASE_URL = ""   # e.g. "https://ludo.yourdomain.com"
WEBAPP_PORT      = 8080

# ╔══════════════════════════════════════════════════════════════════╗
# ║  ⚠️  IMPORTANT — REQUIRED SETUP STEP  ⚠️                          ║
# ║                                                                    ║
# ║  _MONGO_PASS below is a PLACEHOLDER. This is the #1 reason        ║
# ║  commands like /bal, /daily, /rob, /ludo etc. silently fail or    ║
# ║  hang — the bot cannot connect to a real database!                ║
# ║                                                                    ║
# ║  Fix: go to https://cloud.mongodb.com → your cluster →            ║
# ║  Database Access → copy your real user password and paste it      ║
# ║  below. If you don't have a MongoDB Atlas cluster yet, create a   ║
# ║  free M0 cluster (no cost) and copy the connection string.        ║
# ╚══════════════════════════════════════════════════════════════════╝
_MONGO_PASS = "YOUR_MONGODB_PASSWORD"   # 👈 REPLACE THIS with your real password
MONGO_URI = (
    f"mongodb+srv://kalu923476:{quote_plus(_MONGO_PASS)}"
    "@cluster0.tjpjh4k.mongodb.net/iota_bot"
    "?retryWrites=true&w=majority&appName=Cluster0"
)
DB_NAME = "iota_bot"

SARVAM_API_KEY  = "sk_7g5tp3qz_BJC0dd3mk7xsUpC5PCDK4YF4"

# ── AI Provider: Groq (api.groq.com) ──────────────────────────────────
# 🔴 REPLACED: the old provider setup called two unofficial third-party
# proxy services (kilo.ai, x666.me) with hardcoded bearer tokens — not
# documented, official AI providers, just informal reverse-proxies that
# could disappear or get rate-limited/revoked without warning (this is
# exactly what happened to the Tenor GIF API elsewhere in this bot).
# Groq is a real, official provider with a genuine free tier.
#
# ╔══════════════════════════════════════════════════════════════════╗
# ║  Get a free Groq API key (2 minutes, no cost):                   ║
# ║  1. Go to https://console.groq.com/keys                          ║
# ║  2. Sign in → "Create API Key"                                   ║
# ║  3. Paste it below. You can add MULTIPLE keys (one per line in    ║
# ║     the list) — the bot automatically spreads requests across    ║
# ║     all of them and falls back to the next key if one hits a     ║
# ║     rate limit, so more keys = higher effective throughput.      ║
# ╚══════════════════════════════════════════════════════════════════╝
GROQ_API_KEYS = [
    # "gsk_your_first_key_here",
    # "gsk_your_second_key_here",
]

# ── Additional AI Providers (all optional — leave empty to skip) ─────
# The bot tries providers in PRIORITY ORDER (top to bottom): if every
# key for the current provider is rate-limited/down, it automatically
# moves to the next provider entirely, not just the next key. More
# providers configured = much higher effective uptime, since it's very
# unlikely Groq, Gemini, OpenRouter, AND Cloudflare are all rate-limited
# at the same moment.
#
# Free tiers (get a key in ~2 minutes, no card needed for any of these):
#   Gemini:     https://aistudio.google.com/apikey
#   OpenRouter: https://openrouter.ai/keys  (many :free model variants)
#   Cloudflare: https://dash.cloudflare.com/profile/api-tokens
#               (also needs CLOUDFLARE_ACCOUNT_ID below, from your
#               Cloudflare dashboard's right sidebar)
GEMINI_API_KEYS = [
    # "your_gemini_key_here",
]
OPENROUTER_API_KEYS = [
    # "sk-or-your_key_here",
]
CLOUDFLARE_API_KEYS = [
    # "your_cloudflare_api_token_here",
]
CLOUDFLARE_ACCOUNT_ID = ""  # required if using Cloudflare Workers AI
SARVAM_CHAT_URL = "https://api.sarvam.ai/v1/chat/completions"
SARVAM_TTS_URL  = "https://api.sarvam.ai/text-to-speech"

# ── Economy ───────────────────────────────────
DAILY_NORMAL        = 500
DAILY_PREMIUM       = 1250
DAILY_KILLS_NORMAL  = 200
DAILY_KILLS_PREMIUM = 400
DAILY_ROBS_NORMAL   = 150
DAILY_ROBS_PREMIUM  = 300
ROB_MAX_NORMAL      = 10_000
ROB_MAX_PREMIUM     = 100_000
# 🆕 If a rob steals this much or more, the victim gets DM'd about it
# directly (in addition to the group message) so they find out even if
# they're not watching the chat right now.
HIGH_VALUE_THEFT_THRESHOLD = 5_000
TAX_NORMAL          = 0.10
TAX_PREMIUM         = 0.05
KILL_REWARD_NORMAL  = (100, 200)
KILL_REWARD_PREMIUM = (200, 400)
XP_KILL_NORMAL      = (0,   5)
XP_KILL_PREMIUM     = (10, 20)
XP_ROB_PER_1K       = 1
XP_PER_LEVEL        = 1000
REVIVE_COST         = 600    # coins to revive self or others
PROTECT_1D_COST     = 400    # Now costs 400 coins (was free)
PROTECT_2D_COST     = 1000   # Premium only

# ── Premium ───────────────────────────────────
PREMIUM_PRICE_COINS    = 50_000
PREMIUM_PRICE_STARS    = 100   # Goes to owner's Telegram account
PREMIUM_DURATION_DAYS  = 90    # 3 months
GEMS_PRICE_STARS       = 50
GEMS_PRICE_COINS       = 10_000

# ── Card ──────────────────────────────────────
CARD_FEE_PERCENT = 5
CARD_XP_WIN      = 250
CARD_XP_LOSS     = 50
# 🔴 Previously the card game had NO bet limits at all — a user could
# type an absurdly large number (Python has no integer overflow, so
# even a 30-digit "bet" would be silently accepted as a valid int
# before the balance check rejected it). Not exploitable for free
# coins, but still bad practice and inconsistent with every other
# betting game in the bot, which all have real limits. Added here for
# consistency and to close off any weird downstream display bugs a
# huge number could cause.
CARD_MIN_BET     = 10
CARD_MAX_BET     = 100_000
CARD_LOBBY_TIMEOUT_SECONDS = 90  # auto-cancel + refund if nobody joins in time

# ── Items ─────────────────────────────────────
ITEMS = {
    "rose":         ("🌹", 500),
    "chocolate":    ("🍫", 800),
    "ring":         ("💍", 2000),
    "teddy":        ("🧸", 1500),
    "pizza":        ("🍕", 600),
    "surprise_box": ("🎁", 2500),
    "puppy":        ("🐶", 3000),
    "cake":         ("🎂", 1000),
    "love_letter":  ("💌", 400),
    "cat":          ("🐱", 2500),
    "tulip":        ("🌷", 1500),
    "bmw":          ("🏎", 5000),
    "diamond":      ("💎", 8000),
    "crown":        ("👑", 15000),
}

# ── Village ───────────────────────────────────
MINE_INTERVAL   = 3600
CITIZEN_START   = 50
TROOP_TYPES = {
    "warriors": {"hp":50,  "damage":15, "cost_coins":100},
    "archers":  {"hp":30,  "damage":25, "cost_coins":150},
    "knights":  {"hp":100, "damage":20, "cost_coins":200},
    "mages":    {"hp":40,  "damage":40, "cost_coins":300},
}
WALL_TYPES = {
    "wood":  {"hp":300,  "cost_wood":200},
    "stone": {"hp":700,  "cost_stone":300},
    "iron":  {"hp":1500, "cost_iron":400},
}
DEFENSE_TYPES = {
    "archer_tower": {"hp":300, "damage":20, "cost_coins":500},
    "cannon":       {"hp":500, "damage":35, "cost_coins":800},
}

GLOBAL_COUPONS: dict = {
    "nobi10":  1000,
    "iota50":  5000,
    "welcome": 500,
}

# ── GIFs ────────────────────────────────────────────────────────────
# 🔴 REMOVED: the old `_GIFS` static dict (hardcoded giphy.com media IDs)
# and `get_gif()` sync helper. Every one of those hardcoded media IDs
# had rotted (Giphy now returns 403 on all of them) — and separately,
# the Tenor API this bot later switched to was permanently shut down by
# Google on 2026-06-30. All GIFs now come from a live GIPHY search — see
# utils/gif_provider.py, which also documents how to set your own free
# GIPHY API key (recommended — the built-in demo key is a public,
# shared, rate-limited key not meant for real production use).
#
# ╔══════════════════════════════════════════════════════════════════╗
# ║  Recommended: get your own free GIPHY key                        ║
# ║  1. Go to https://developers.giphy.com/dashboard/                ║
# ║  2. Create an account → "Create an App" → pick "API"             ║
# ║  3. Copy the key it gives you and paste it below                 ║
# ║  A beta key is instant, free, and good for 100 requests/hour —   ║
# ║  plenty for a Telegram bot. Leave blank to use the shared public ║
# ║  demo key (works out of the box, but is rate-limited across      ║
# ║  every bot using it, so GIFs may occasionally be slow/unavailable║
# ║  under heavy load).                                               ║
# ╚══════════════════════════════════════════════════════════════════╝
GIPHY_API_KEY = "Wewdpr7TcsF0FS6vJghVf28ktFej4OTe"   # 👈 paste your own key here (optional but recommended)
