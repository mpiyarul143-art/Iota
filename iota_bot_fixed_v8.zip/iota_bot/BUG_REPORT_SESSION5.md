# 🐛 Session Changelog — /q rendering, promote levels, AI provider overhaul

## 🔴 Critical fixes

### 1. `/globalclose` crash — `_is_owner` not defined
**File**: `handlers/owner_panel.py`
Exactly the crash from your screenshot. The actual ownership-check
function is named `_own()`, not `_is_owner()` — `globalclose_cmd`/
`globalopen_cmd` called the wrong name. Also cleaned up a messy
decorator placement (a stray `@owner_only` sitting above a comment
block instead of directly above the function) and added the missing
`@owner_only` to `globalopen_cmd` (it had none at all — only a manual
check with no exception safety net).

### 2. `/q` sticker — emoji rendering completely rewritten
**Files**: `utils/quote_render.py`
Two real bugs, now both fixed:
- No color-emoji font was ever actually used — emoji like ❌ ✦ 🎉
  rendered as broken tofu boxes (or nothing at all).
- `NotoColorEmoji.ttf` is a **bitmap** font — it only works at its one
  native size (109px), not arbitrary sizes. The previous attempt to
  load it at custom sizes silently failed with "invalid pixel size."
  Now each emoji is rendered once at 109px, cropped, and resized to
  match the surrounding text — full color, correct size, cached per
  (emoji, size) pair so repeated stickers stay fast.
- Also fixed `font_manager.py` making 3 wasted network calls (and
  logging 403 errors) on every single `/q` — it now checks bundled →
  system fonts first, only falling back to a network download as an
  actual last resort.

## 🥇🥈🥉 `.promote` — restructured to exactly 3 levels

**File**: `handlers/admin.py`
Per your spec: `.promote user 1` = Junior (delete messages, restrict
members only), `.promote user 2` = Admin (adds invite/pin/change info),
`.promote user 3` = Full Admin (adds promote members + manage chat).
`.unpromote` now works too — it was referenced nowhere before, so it
silently did nothing.

## 👑 Owner bypass for admin commands

**File**: `handlers/admin.py`
The bot owner can now run `.promote`/`.demote`/any dot-admin command in
**any** group Iota is in, even without being an admin there themselves
— as long as Iota herself already has admin rights with the right
permission in that group. This can never grant more power than Iota
actually has: if she lacks the specific permission, Telegram's own API
rejects the actual action with a clear error, same as any admin trying
to do something they don't have rights for.

## 💓 `/premiumgiveaway` — real premium as the prize

**File**: `handlers/owner_panel.py` (owner-only)
`/premiumgiveaway <minutes> <days> [winner_count]` — distinct from the
existing generic `/giveaway` (any admin, any text prize). This one
actually **grants** Iota Premium to the winner(s) automatically the
moment it ends — no manual follow-up `/addpremium` needed.

## 🤖 AI Provider — complete rewrite (Groq + Key Pool + Fallback)

**File**: `utils/ai_provider.py` (rewritten), `config.py`, `handlers/owner_panel.py`

Replaced the old kilo.ai / x666.me setup (unofficial third-party
proxies with hardcoded tokens — the exact kind of fragile dependency
that broke this bot's GIF and font systems elsewhere) with **Groq**, a
real official provider, built around everything from your spec:

- **API Key Pool**: multiple Groq keys tracked independently
- **Intelligent fallback**: a failed/rate-limited key is automatically
  skipped and the next healthy key tried, within the same call
- **Smart cooldown**: a key that hits 429/500/502/503/504/timeout is
  marked "cooling down" for 60s (configurable) instead of retried
  immediately
- **Health monitoring**: per-key status/requests/successes/failures/
  last error, viewable via `/keypoolstatus`
- **Real-time model fetching**: `/refreshmodels` pulls the actual live
  model list from Groq's `/models` endpoint — never a stale hardcoded
  list
- **Persisted config**: models, max_tokens, and owner-added keys all
  survive a bot restart (stored in MongoDB)

New owner commands:
- `/addapikey <key>` / `/removeapikey <prefix>` — manage the key pool
- `/keypoolstatus` — health of every key
- `/refreshmodels` — force a fresh live model fetch from Groq
- `/setmaxtokens <n>` — response length cap for all AI features
- `/setmodel free|premium <model>` / `/listmodels` — updated, no more
  Kilo.ai/x666.me branding

**Setup**: get a free key at https://console.groq.com/keys and add it
either in `config.py` (`GROQ_API_KEYS = [...]`) or live via
`/addapikey` — no restart needed for the latter.

## 🎲 Fresh AI content instead of repeating static lists

**File**: `handlers/extra_games.py`
`/roast`, `/compliment`, and `/meme` now generate their content live
via AI each time (falling back to the old static list only if the AI
call fails, so they never break) — matching the new `/aijoke`,
`/roastme`, `/aistory`, `/advice` added earlier. `/meme` also no longer
uses the same rotted `media.giphy.com` links found dead elsewhere in
this bot — it now pulls a live GIF the same way everything else does.

## 📖 `/help` — fully updated

**File**: `handlers/start.py`
Added two new menu sections (🛡️ Admin, 🧰 Toys) and updated Economy,
Village, Fun, and AI Chat menus to list every command added across this
whole project — bank/loan/lottery, donate/repair/raidlog/recruit, the
12 new fun actions, the new admin commands, and the new AI features.

## ✅ Verified
- All 68 Python files compile with zero syntax errors
- Zero cross-module import mismatches (full AST re-check)
- Zero duplicate command registrations across 293 registered commands
