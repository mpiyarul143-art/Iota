# 🆕 20 New Features (v8 addition #2)

New file: `handlers/new_features_v2.py` (+ storage helpers in
`utils/mongo_db.py`). All 271 commands checked clean: 0 syntax errors,
0 broken imports, 0 duplicate registrations.

## Admin — message management
1. **/pin** — pin the replied-to message (`silent` option to pin quietly)
2. **/unpin** — unpin (replied message, or the current pin if no reply)
3. **/purge** — bulk-delete every message between a replied message and
   the `/purge` command itself; reports how many were skipped (Telegram
   only allows deleting messages under 48h old — surfaced clearly
   instead of silently skipping)

## Profile
4. **/avatar** — shows a user's current profile photo (reply to someone,
   or run it alone for your own)

## Fun / trivia
5. **/8ball** — magic 8-ball yes/no answers
6. **/joke** — random Hinglish/English jokes
7. **/fact** — random fun facts
8. **/riddle** — riddle with a tap-to-reveal answer button
9. **/wyr** — "would you rather" prompts

## Text toys
10. **/reverse** — reverses given text
11. **/mock** — sPoNgeBoB-style mocking text
12. **/binary** — text → binary
13. **/morse** — text → Morse code
14. **/hash** — MD5 + SHA-256 of given text
15. **/password** — generates a cryptographically secure random password
    (uses Python's `secrets` module, not `random` — this matters for an
    actual password generator)

## Social / utility
16. **/nickname** — set what Iota calls you (stored per-user)
17. **/birthday DD-MM** — Iota wishes you automatically on that day
    (new background loop, `birthday_daily_loop`, checks once around
    9 AM IST daily and tracks the last date it ran so a restart or slow
    tick can never double-wish the same day)
18. **/todo** — personal to-do list (`add`/`done <n>`/`clear`)
19. **/countdown EventName YYYY-MM-DD** — days-remaining counter,
    multiple countdowns per person
20. **/giveaway <minutes> <prize>** — admin-run giveaway with a
    join button; picks a random winner automatically when time's up

## Deliberately NOT included
A "show last deleted message" (/snipe) feature was considered but
skipped on purpose: Telegram's Bot API has **no event for message
deletion at all** — a legitimate bot literally cannot know a message
was deleted. Implementing this honestly would require a separate
userbot/MTProto session, which carries real Telegram ToS risk and is
out of scope here. Including a fake/broken version of it would have
violated the "0 bugs" ask more than leaving it out.
