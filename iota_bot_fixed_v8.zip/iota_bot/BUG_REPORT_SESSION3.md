# 🐛 Iota Bot — Third Pass: New Features + More Critical Bugs Found

## 🆕 NEW FEATURES

### 1. Sticker/GIF mirroring + auto message reactions (like "Baka")
**Already existed** in `handlers/sticker_reply.py` + `utils/reactions.py`,
already wired into `bot.py` — sticker→sticker, GIF→GIF, and Telegram
native emoji reactions on user messages, all mood/content-aware. If you
weren't seeing this behavior, it may have been masked by the GIF-system
bugs below (fixed now) — worth testing again after this update.

### 2. Mood-based GIF sent alongside Iota's own chat replies
**File**: `handlers/ai_chat.py`
New — this didn't exist before. Iota now sometimes (~25% of replies,
only when her own reply clearly has a mood like laughing/sad/love/
angry/surprised) sends a matching GIF right after her text, sourced
live from GIPHY — never the same fallback GIF every time, and never on
every single message (that would feel spammy/mechanical).

### 3. `/globalclose` and `/globalopen` (new owner commands)
**File**: `handlers/owner_panel.py`
Owner-only. Same as `/close` and `/open` but applies to economy/games/
village across **every** group the bot is in at once — for maintenance
or a temporary global freeze, without visiting each group individually.

### 4. 12 new fun action commands
**File**: `handlers/fun.py`
`/fall`, `/throw`, `/kick`, `/highfive`, `/poke`, `/tickle`,
`/facepalm`, `/pie`, `/trip`, `/freeze`, `/zap`, `/dancewith` — same
reply-required + self-check + bot-immunity + mood-matched-GIF pattern
as the existing `/slap`/`/punch`/`/murder`, built off one shared
factory function so there's no duplicated/inconsistent logic between
all 17 action commands now.

---

## 🔴 CRITICAL BUGS FOUND & FIXED

### 5. `/close` and `/open` did NOTHING — the actual check was never wired in
**Files**: `bot.py`, `handlers/games.py`, `utils/mongo_db.py`
This was the big one. `set_system_status()` (called by `/close`) and
`get_system_status()` both existed and worked — `/close` genuinely
wrote "closed" to the database — but **no command anywhere ever called
`get_system_status()` before running**. So `/close` looked like it
worked (gave a confirmation message) while every economy/games/village
command kept running completely normally. Fixed by wrapping all
economy/games/village command registrations in `bot.py` with a shared
enforcement check (`/open`, `/close`, `/game`, `/leaders`, `/economy`,
`/guide`, and coupon commands stay exempt so admins can always manage
things even while the rest is closed).

### 6. `.promote`, `.demote`, `.demoteall`, `.add`, `.remove` — ALL silently broken
**Files**: `handlers/admin.py`, `handlers/group_tools.py`
Telegram's `ChatAdministratorRights` requires 8 specific fields
(`is_anonymous`, `can_manage_chat`, `can_delete_messages`,
`can_manage_video_chats`, `can_restrict_members`, `can_promote_members`,
`can_change_info`, `can_invite_users`) to always be passed explicitly —
none of them have defaults. Every single admin-rights command in this
bot was only passing a partial dict, which raises `TypeError` on
literally every call. Since that's not a `TelegramError`, the existing
`except TelegramError` never caught it — the command just did nothing
at all, with no error message, which is exactly "promote command
achha se kaam nahi kar raha" (promote not working well). Added one
`_build_rights()` helper that fills every required field safely, used
everywhere `ChatAdministratorRights` is constructed (6 call sites).

### 7. `/q` sticker — tofu boxes + broken font download URLs
**Files**: `utils/quote_render.py`, `utils/font_manager.py`
Two separate bugs:
- No emoji-capable font was ever bundled or loaded, so any emoji in a
  quoted message (like 🥺) rendered as a broken glyph box right in the
  sticker. Now stripped cleanly before rendering — matches the exact
  bug from your screenshot.
- The Noto font auto-download URLs pointed at a reorganized GitHub repo
  path that no longer exists (confirmed 403). Repointed to a stable
  mirror, and added more system-font fallback paths (with a note that
  `apt install fonts-noto-core` is the most durable long-term fix,
  since it removes the runtime-download dependency entirely).
- Also enlarged the card's avatar/name/text sizing for a punchier look.

### 8. Iota's small-caps text style didn't match the reference look
**File**: `utils/fonts.py`
The existing `sc()` smallcaps engine converted every letter uniformly.
Your reference screenshots ("Aʟʟ Eᴄᴏɴᴏᴍʏ Cᴏᴍᴍᴀɴᴅꜱ...") keep each word's
first letter as a normal bold capital and small-cap only the rest.
Fixed to match exactly — this automatically improves formatting
everywhere `sc()` is already used across the bot (admin actions,
warnings, `/close`/`/open`, etc.) with no per-message changes needed.

### 9. GIPHY key installed
Your personal key is now in `config.py` as `GIPHY_API_KEY` — GIFs no
longer depend on the shared, rate-limited public demo key.

### 10. AI persona: deeper human-girl realism
**File**: `handlers/ai_chat.py`
Researched natural conversational-AI writing practices and added a new
"how to actually think" section to the prompt: react to what was
literally just said instead of a generic vibe response, vary sentence
rhythm, have small opinions instead of staying neutral, and —
specifically per your request — stop steering conversation toward
games/commands or mentioning search/lookups unless the person actually
asked. Kept the cute/flirty/sassy voice and all the safety-net fixes
(search-leak stripping, no-fabricated-links, `/connect` shared memory).

---

## ✅ Verified after all changes
- All 66 Python files compile with zero syntax errors.
- Zero cross-module import mismatches (every `from X import Y`
  resolves to something real) — re-checked via full AST analysis.
- Zero duplicate command registrations across 251 registered commands.
